import React from 'react'
import { useNavigate, useParams } from 'react-router-dom'

import "./Detail.css"
function Detail() {
  const {id}=useParams()
const navigate = useNavigate()

  return (
    <div>
      <div className="container">
        
      </div>
    </div>
  )
}

export default Detail
